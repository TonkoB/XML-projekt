POKRETANJE:

1.) instalirati XAMPP i startati Apache server (https://www.apachefriends.org/xampp-files/7.4.4/xampp-windows-x64-7.4.4-1-VC15-installer.exe)
2.) u C:\xampp\htdocs kopirati file projekt.php i priloženi folder sa slikama
3.) otvoriti u browseru http://localhost/projekt.php


SVRHA:

Zapis dnevnika(u obliku forme) svemirskog putnika u ne tako dalekoj budućnosti. 
Korisnik bi ispunjavanjem forme i njenim slanjem generirao XML datoteku, s datumom unosa.
XML je zapisan pomoću php-a, a sama forma je realizirana pomoću HTML5-a i CSS-a (W3 custom CSS + Bootstrap + vlastiti CSS). 
Svaki XML u imenu ima datum i vrijeme kada je ispunjen pa na temelju toga, korisnik može voditi dnevnik o putovanju.

Link na github: https://github.com/TonkoB/XML-projekt
Link na YT video: https://youtu.be/yyD7L_IvVeo