<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
                <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

        <!-- Popper JS -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

        <!-- Latest compiled JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script> 
        <link rel="stylesheet" type="text/css" href="style.css"> 
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <title>Svemirski dnevnik XML</title>
    </head>

    <body>
            <header class="glava">
                 <nav>
                    <ul id="nav">
                        <li> <h5><a target="_blank" href="https://stellarium-web.org/">StarMap</a></h5> </li>
                        <li> <h5><a target="_blank" href="https://exoplanets.nasa.gov/">Exoplanets</a></h5> </li>
                        <li> <h5><a target="_blank" href="https://www.youtube.com/watch?v=TN0S165XD1Q">Aliens</a></h5> </li>   
                    </ul> 
                </nav>
            </header>
           
            
        <div class="container" id="centar">

            <h2> SVEMIR </h2><hr>


        <div class="container-fluid" id="levo">
                
            <section>

                <p id="prica">U dalekoj ste budućnosti. Sami putujete galaksijom u svome svemirskom brodu.
                    Odlučili ste pisati dnevnik o prizorima koje viđate na putovanju. Kompjuter Vam nudi
                    pisanje u obliku forme...
                 <br>
                </p>

                <form enctype="multipart/form-data" action="projekt.php" method="POST" name="Forma">

                    <label for="autor"><b>Autor:</b></label><br>
                    <input type="text" name="ime" class="w3-input w3-animate-input" style="width:20%; background-color:transparent; color:white;" required><br><br>

                    <label for="brod"><b>Naziv broda:</b></label><br>
                    <input type="text" name="brod" class="w3-input w3-animate-input" style="width:20%; background-color:transparent; color:white;" required><br><br>

                    <label for="godina"><b>Trenutni datum:</b></label><br>
                    <input type="date" name="date" class="form-control" style="width:15%; background-color:transparent; color:white;" required><br><br>

                    <label for="godputovanja"><b>Koliko godina putujete?</b></label><br>
                    <input type="range" min="1" max="1000" step="1" name="godputovanja" id="myRange"  style="width:20%;"><br>
                    Već:<span id="broj"></span> godina!<br><br>
                    <script language="JavaScript">
							var slider2 = document.getElementById("myRange");
							var output2 = document.getElementById("broj");
							output2.innerHTML = slider2.value;

							slider2.oninput = function() {
								output2.innerHTML = this.value;
							}
					</script>

                    <label for="galaksija"><b>Trenutna galaksija: </b></label><br>
                    <select class="w3-select" name="galaksija" id="galaksija" style="width:20%; background-color:transparent; color:white;" required>

                        <option name="Andromeda">Andromeda</option>
                        <option name="Mliječna">Milkyway</option>
                        <option name="Cigar">Cigar Galaxy</option>
                        <option name="Sauron">Eye of Sauron</option>
                        <option name="Black">Black Eye</option>
                        <option name="Sombrero">Little Sombrero Galaxy</option>
                        
                    </select> <br><br>


                    <label for="objekti"><b>Koje od slijedećih rijetkih svemirskih objekata ste već vidjeli? :</b></label><br>
                    <input type="checkbox" id="crnarupa" name="crnarupa" value="crna rupa"> Crna rupa <br>
                    <input type="checkbox" id="bijelarupa" name="bijelarupa" value="bijela rupa"> Bijela rupa <br>
                    <input type="checkbox" id="kvazar" name="kvazar" value="kvazar"> Kvazar <br>
                    <input type="checkbox" id="maglica" name="maglica" value="maglica"> Maglica <br>
                    <input type="checkbox" id="pulsar" name="pulsar" value="pulsar"> Pulsar <br>
                    <input type="checkbox" id="magnetar" name="magnetar" value="magnetar"> Magnetar <br>
                    <input type="checkbox" id="neutronska" name="neutronska" value="neutronska"> Neutronska zvijezda <br><br>


                    <label for="planeti"><b>Koje vrste zvijezda ste već posjetili? :</b></label><br>
                    <input type="checkbox" id="plavid" name="plavid" value="plavi div"> Plavi div <br>
                    <input type="checkbox" id="bijelip" name="bijelip" value="bijeli patuljak"> Bijeli patuljak <br>
                    <input type="checkbox" id="crvenid" name="crvenid" value="crveni div"> Crveni div <br>
                    <input type="checkbox" id="smeđid" name="smeđid" value="smeđi div"> Smeđi div <br><br>
                  

                    <label for="aliens"><b> Želite li upoznati vanzemaljce? :</b></label><br>
                    <input type="radio" id="da" name="alien" value="da" required> Da
                    <input type="radio" id="ne" name="alien" value="ne" required> Ne <br><br>

                    <label for="komentar"><b>Što Vas se najviše dojmilo na putovanju dosad? :</b></label><br>
                    <textarea rows="3" name="komentar" id="komentar" style="width:40%; background-color:transparent; color:white;"></textarea><br><br>

                    <label for="film"><b>Najdraži SciFi film Vam je? :</b></label><br>
                    <input type="text" name="film" id="film" class="w3-input w3-animate-input" style="width:20%; background-color:transparent; color:white;"><br><br>
  
                    <button type="reset" name="Reset" class="w3-btn w3-red" id="butN"><b>Poništi</b></button> 
                    <button type="submit" name="Posalji" class="w3-btn w3-blue" id="but"><b>Pošalji</b></button>
                    
                </form>
            </section>

        </div>

             
        </div>

        <footer class="noga">
            <h1>Svemirski dnevnik XML</h1>
        </footer>

       
    </body>

</html>

<?php

date_default_timezone_set('Europe/Zagreb');

if(isset($_POST['Posalji'])) {

    $autor = $_POST['ime'];
    $naziv = $_POST['brod'];
    $godina = $_POST['date'];
    $godput = $_POST['godputovanja'];
    $galaksija = $_POST['galaksija'];
    $aliens = $_POST['alien'];
    $komentar = $_POST['komentar'];
    $film = $_POST['film'];

    $objekti = "\t<Sobjekti>\n";
			if (isset($_POST['crnarupa'])) {
				$objekti .= "\t\t<Objekt>" . $_POST['crnarupa'] . "</Objekt>\n";
			}
			if (isset($_POST['bijelarupa'])) {
				$objekti .= "\t\t<Objekt>" . $_POST['bijelarupa'] . "</Objekt>\n";
			}
			if (isset($_POST['kvazar'])) {
				$objekti .= "\t\t<Objekt>" . $_POST['kvazar'] . "</Objekt>\n";
			}
			if (isset($_POST['maglica'])) {
				$objekti .= "\t\t<Objekt>" . $_POST['maglica'] . "</Objekt>\n";
			}
			if (isset($_POST['pulsar'])) {
				$objekti .= "\t\t<Objekt>" . $_POST['pulsar'] . "</Objekt>\n";
			}
			if (isset($_POST['magnetar'])) {
				$objekti .= "\t\t<Objekt>" . $_POST['magnetar'] . "</Objekt>\n";
			}
			if (isset($_POST['neutronska'])) {
				$objekti .= "\t\t<Objekt>" . $_POST['neutronska'] . "</Objekt>\n";
			}
    $objekti .= "\t</Sobjetki>\n";


    $zvijezde = "\t<Zvijezde>\n";
			if (isset($_POST['plavid'])) {
				$zvijezde .= "\t\t<Zvijezda>" . $_POST['plavid'] . "</Zvijezda>\n";
			}
			if (isset($_POST['bijelip'])) {
				$zvijezde .= "\t\t<Zvijezda>" . $_POST['bijelip'] . "</Zvijezda>\n";
			}
			if (isset($_POST['crvenid'])) {
				$zvijezde .= "\t\t<Zvijezda>" . $_POST['crvenid'] . "</Zvijezda>\n";
			}
			if (isset($_POST['smeđid'])) {
				$zvijezde .= "\t\t<Zvijezda>" . $_POST['smeđid'] . "</Zvijezda>\n";
			}
    $zvijezde .= "\t</Zvijezde>\n";


    $result = '';

    $result = $result . '<Dnevnik>';

    $result .= '<Autor>' . $autor . '</Autor>';

    $result .= '<NazivBroda>' . $naziv . '</NazivBroda>';

    $result .= '<TrenutnaGodina>' . $godina . '</TrenutnaGodina>';

    $result .= '<GodinaPutovanja>' . $godput . '</GodinaPutovanja>';
    
    $result .= '<TrenutnaGalaksija>' . $galaksija . '</TrenutnaGalaksija>';

    $result .= $objekti;

    $result .= $zvijezde;

    $result .= '<Vanzemaljci>' . $aliens . '</Vanzemaljci>';

    $result .= '<Dojam>' . $komentar . '</Dojam>';

    $result .= '<Film>' . $film . '</Film>';

    $result .= '</Dnevnik>';

    

    $filename = 'SvemirskiDnevnik_' . date('Y-m-d_H-i-s') . '.xml';
    file_put_contents($filename, $result);
    


}
else {
    echo '';
}

?>


